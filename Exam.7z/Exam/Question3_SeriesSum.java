import Exam.Calculate.Sum;
import Exam.Number.Check;
import java.util.*;

public class demo {
	public static void main(String args[]){
		Sum sumObj = new Sum(50);
		System.out.println(sumObj.getSum());
		
		Check checkObj = new Check(555);
		System.out.println(checkObj.isZero() + checkObj.isEven());

	}
}